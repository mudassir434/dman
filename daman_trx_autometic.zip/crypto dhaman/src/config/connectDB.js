const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: '184.168.102.191',
    user: 'tron',
    password: 'Tron@123',
    database: 'tron'
});


export default connection;